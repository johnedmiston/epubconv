#!/usr/bin/env python3
"""
Cybermissions DOCX → EPUB Batch Converter
==========================================
Converts folders of .docx files to .epub using Pandoc as the core engine.
Handles tables, embedded images, footnotes, and multilingual content.

Usage:
    python convert.py --input "C:/path/to/languages" --output "C:/path/to/output"
    python convert.py --input "C:/languages/Swahili" --output "C:/output/Swahili" --lang sw
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET

# ── Language code map (folder name → BCP-47 code for EPUB metadata) ──────────
LANGUAGE_MAP = {
    "afrikaans": "af", "amharic": "am", "arabic": "ar", "bengali": "bn",
    "burmese": "my", "chinese": "zh", "english": "en", "french": "fr",
    "hausa": "ha", "hindi": "hi", "indonesian": "id", "kiswahili": "sw",
    "swahili": "sw", "malagasy": "mg", "oromo": "om", "portuguese": "pt",
    "shona": "sn", "somali": "so", "spanish": "es", "tagalog": "tl",
    "tamil": "ta", "tigrinya": "ti", "urdu": "ur", "yoruba": "yo",
    "zulu": "zu", "igbo": "ig", "twi": "ak", "lingala": "ln",
}

# ── RTL languages that need special handling ──────────────────────────────────
RTL_LANGUAGES = {"ar", "ur", "he", "fa", "yi"}


def detect_language(folder_name: str) -> str:
    """Guess BCP-47 language code from folder name."""
    name = folder_name.lower().strip()
    return LANGUAGE_MAP.get(name, "en")


def check_pandoc() -> str:
    """Verify pandoc is installed and return version string."""
    try:
        result = subprocess.run(
            ["pandoc", "--version"], capture_output=True, text=True, check=True
        )
        return result.stdout.split("\n")[0]
    except (FileNotFoundError, subprocess.CalledProcessError):
        return None


def pre_check_docx(docx_path: Path) -> dict:
    """
    Inspect a DOCX file before conversion and flag potential issues.
    Returns a dict of warnings the user should know about.
    """
    warnings = []
    info = {"smartart": False, "heading_styles": False, "images": 0, "tables": 0}

    try:
        with zipfile.ZipFile(docx_path, "r") as z:
            names = z.namelist()

            # Check for SmartArt (won't convert well)
            if any("diagrams" in n or "drawing" in n.lower() for n in names):
                # Read document XML to check for SmartArt specifically
                if "word/document.xml" in names:
                    xml = z.read("word/document.xml").decode("utf-8", errors="ignore")
                    if "dgm:" in xml or "SmartArt" in xml:
                        info["smartart"] = True
                        warnings.append(
                            "Contains SmartArt diagrams — these will NOT convert. "
                            "Screenshot them as PNG images before converting."
                        )

            # Count images
            info["images"] = sum(
                1 for n in names if n.startswith("word/media/")
                and any(n.endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".gif", ".emf", ".wmf"])
            )
            if any(n.endswith((".emf", ".wmf")) for n in names):
                warnings.append(
                    "Contains EMF/WMF vector images — these may not render on all devices. "
                    "Consider converting to PNG in Word first."
                )

            # Check document XML for heading styles and tables
            if "word/document.xml" in names:
                xml = z.read("word/document.xml").decode("utf-8", errors="ignore")
                info["heading_styles"] = bool(
                    re.search(r'w:val="Heading\s*[1-6]"', xml)
                )
                info["tables"] = xml.count("<w:tbl>")
                if not info["heading_styles"]:
                    warnings.append(
                        "No Heading styles detected — document may lack navigation. "
                        "In Word: apply Heading 1/2/3 styles to chapter/section titles."
                    )

    except Exception as e:
        warnings.append(f"Could not pre-inspect file: {e}")

    return {"info": info, "warnings": warnings}


def build_pandoc_command(
    input_path: Path,
    output_path: Path,
    css_path: Path,
    lang_code: str,
    title: str = None,
    epub3: bool = True,
) -> list:
    """Build the pandoc command list for a single conversion."""
    epub_version = "epub" if epub3 else "epub2"

    cmd = [
        "pandoc",
        str(input_path),
        "-o", str(output_path),
        "-t", epub_version,
        "--css", str(css_path),
        "--epub-embed-font",               # embed fonts if present
        "--toc",                           # generate table of contents
        "--toc-depth=3",
        "--wrap=none",                     # don't hard-wrap lines
        "--extract-media=.",               # keep images relative
        "-M", f"lang={lang_code}",
        "-M", "rights=© Cybermissions — Free distribution permitted",
        "-M", "creator=Cybermissions (cybermissions.org)",
    ]

    if title:
        # Sanitize title for metadata
        safe_title = title.replace('"', "'")
        cmd += ["-M", f"title={safe_title}"]

    if lang_code in RTL_LANGUAGES:
        cmd += ["-M", "dir=rtl"]

    return cmd


def convert_file(
    docx_path: Path,
    output_dir: Path,
    css_path: Path,
    lang_code: str,
    verbose: bool = False,
) -> dict:
    """
    Convert a single DOCX to EPUB.
    Returns a result dict with success/failure info.
    """
    stem = docx_path.stem
    epub_path = output_dir / (stem + ".epub")
    title = stem.replace("_", " ").replace("-", " ")

    result = {
        "file": docx_path.name,
        "output": epub_path.name,
        "success": False,
        "warnings": [],
        "error": None,
        "info": {},
    }

    # Pre-flight checks
    check = pre_check_docx(docx_path)
    result["warnings"] = check["warnings"]
    result["info"] = check["info"]

    # Build and run pandoc
    cmd = build_pandoc_command(
        docx_path, epub_path, css_path, lang_code, title
    )

    if verbose:
        print(f"    Running: {' '.join(cmd[:6])} ...")

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,  # 2 minute timeout per file
        )

        if proc.returncode == 0:
            result["success"] = True
            # Capture pandoc warnings (often useful)
            if proc.stderr.strip():
                for line in proc.stderr.strip().split("\n"):
                    if line.strip() and "WARNING" in line.upper():
                        result["warnings"].append(f"Pandoc: {line.strip()}")
        else:
            result["error"] = proc.stderr.strip() or "Pandoc exited with error"

    except subprocess.TimeoutExpired:
        result["error"] = "Conversion timed out after 2 minutes"
    except FileNotFoundError:
        result["error"] = (
            "Pandoc not found. Please install from https://pandoc.org/installing.html"
        )
    except Exception as e:
        result["error"] = str(e)

    # Report file sizes
    if result["success"] and epub_path.exists():
        size_kb = epub_path.stat().st_size // 1024
        result["size_kb"] = size_kb

    return result


def process_folder(
    input_dir: Path,
    output_dir: Path,
    css_path: Path,
    lang_code: str,
    verbose: bool = False,
) -> list:
    """Convert all DOCX files in a folder. Returns list of result dicts."""
    docx_files = sorted(input_dir.glob("*.docx"))
    # Exclude temp files Word creates (start with ~$)
    docx_files = [f for f in docx_files if not f.name.startswith("~$")]

    if not docx_files:
        return []

    output_dir.mkdir(parents=True, exist_ok=True)
    results = []

    for i, docx_path in enumerate(docx_files, 1):
        print(f"  [{i}/{len(docx_files)}] {docx_path.name}", end="", flush=True)
        result = convert_file(docx_path, output_dir, css_path, lang_code, verbose)

        if result["success"]:
            size = result.get("size_kb", "?")
            warn_count = len(result["warnings"])
            print(f" ✓ ({size} KB)" + (f" [{warn_count} warnings]" if warn_count else ""))
        else:
            print(f" ✗ FAILED: {result['error'][:80]}")

        results.append(result)

    return results


def write_report(all_results: dict, output_base: Path):
    """Write a detailed HTML report of the conversion run."""
    report_path = output_base / "conversion_report.html"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")

    total = sum(len(v) for v in all_results.values())
    succeeded = sum(
        sum(1 for r in v if r["success"]) for v in all_results.values()
    )
    failed = total - succeeded
    needs_attention = sum(
        sum(1 for r in v if r["warnings"]) for v in all_results.values()
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cybermissions EPUB Conversion Report — {timestamp}</title>
<style>
  body {{ font-family: Arial, sans-serif; max-width: 960px; margin: 40px auto; color: #333; }}
  h1 {{ color: #1a5276; border-bottom: 3px solid #1a5276; padding-bottom: 8px; }}
  h2 {{ color: #1a5276; margin-top: 32px; }}
  .summary {{ display: flex; gap: 20px; margin: 20px 0; flex-wrap: wrap; }}
  .stat {{ background: #f0f4f8; border-radius: 8px; padding: 16px 24px; text-align: center; min-width: 120px; }}
  .stat .num {{ font-size: 2em; font-weight: bold; }}
  .stat .label {{ font-size: 0.85em; color: #666; margin-top: 4px; }}
  .ok {{ color: #1e8449; }}
  .fail {{ color: #c0392b; }}
  .warn {{ color: #d68910; }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 12px; font-size: 0.9em; }}
  th {{ background: #1a5276; color: white; padding: 8px 12px; text-align: left; }}
  tr:nth-child(even) {{ background: #f9f9f9; }}
  td {{ padding: 7px 12px; border-bottom: 1px solid #e0e0e0; vertical-align: top; }}
  .tag-warn {{ background: #fdebd0; color: #d35400; border-radius: 4px; padding: 2px 6px; font-size: 0.8em; }}
  .tag-fail {{ background: #fadbd8; color: #c0392b; border-radius: 4px; padding: 2px 6px; font-size: 0.8em; }}
  .tag-ok {{ background: #d5f5e3; color: #1e8449; border-radius: 4px; padding: 2px 6px; font-size: 0.8em; }}
  ul {{ margin: 4px 0; padding-left: 18px; }}
  li {{ margin-bottom: 2px; }}
  .footer {{ margin-top: 40px; font-size: 0.8em; color: #999; border-top: 1px solid #eee; padding-top: 12px; }}
</style>
</head>
<body>
<h1>📚 Cybermissions EPUB Conversion Report</h1>
<p>Generated: {timestamp}</p>

<div class="summary">
  <div class="stat"><div class="num">{total}</div><div class="label">Total Files</div></div>
  <div class="stat"><div class="num ok">{succeeded}</div><div class="label">Succeeded</div></div>
  <div class="stat"><div class="num fail">{failed}</div><div class="label">Failed</div></div>
  <div class="stat"><div class="num warn">{needs_attention}</div><div class="label">Need Review</div></div>
</div>
"""

    for lang_folder, results in sorted(all_results.items()):
        if not results:
            continue
        lang_ok = sum(1 for r in results if r["success"])
        html += f"""
<h2>📁 {lang_folder} &nbsp;<small>({lang_ok}/{len(results)} converted)</small></h2>
<table>
  <tr><th>File</th><th>Status</th><th>Tables</th><th>Images</th><th>Notes</th></tr>
"""
        for r in results:
            if r["success"]:
                status = f'<span class="tag-ok">✓ OK — {r.get("size_kb","?")} KB</span>'
            else:
                status = f'<span class="tag-fail">✗ Failed</span>'

            tables = r["info"].get("tables", "—")
            images = r["info"].get("images", "—")

            notes_items = []
            if r.get("error"):
                notes_items.append(f'<li><b>Error:</b> {r["error"]}</li>')
            for w in r.get("warnings", []):
                notes_items.append(f'<li>{w}</li>')

            if r["info"].get("smartart"):
                notes_items.append('<li><b>⚠ SmartArt detected</b> — screenshot as PNG</li>')

            notes = f"<ul>{''.join(notes_items)}</ul>" if notes_items else "—"
            tag = "warn" if r["warnings"] and r["success"] else ("fail" if not r["success"] else "")

            html += f"""  <tr class="{tag}">
    <td>{r["file"]}</td>
    <td>{status}</td>
    <td>{tables}</td>
    <td>{images}</td>
    <td>{notes}</td>
  </tr>
"""
        html += "</table>\n"

    html += """
<div class="footer">
  <p>Cybermissions Batch Converter · Powered by Pandoc · cybermissions.org</p>
  <h3>Common Issues & Fixes</h3>
  <ul>
    <li><b>Missing navigation:</b> In Word, apply Heading 1/2/3 styles to chapter/section titles (not just bold text).</li>
    <li><b>SmartArt diagrams:</b> Right-click the SmartArt → Save as Picture (PNG), then insert the PNG back into the document.</li>
    <li><b>EMF/WMF images:</b> These are Windows-only vector formats. Right-click each image → Save as Picture → PNG.</li>
    <li><b>Broken tables:</b> Very wide tables may need to be split or simplified for mobile screens.</li>
    <li><b>Failed conversion:</b> Ensure Pandoc is installed from pandoc.org and is in your system PATH.</li>
  </ul>
</div>
</body>
</html>"""

    report_path.write_text(html, encoding="utf-8")
    return report_path


def main():
    parser = argparse.ArgumentParser(
        description="Cybermissions DOCX → EPUB Batch Converter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--input", "-i", required=True,
        help="Input folder. Either a single language folder OR a parent folder containing language subfolders."
    )
    parser.add_argument(
        "--output", "-o", required=True,
        help="Output folder. Structure mirrors input."
    )
    parser.add_argument(
        "--lang", "-l", default=None,
        help="BCP-47 language code (e.g. sw, fr, ar). Auto-detected from folder name if omitted."
    )
    parser.add_argument(
        "--css", default=None,
        help="Path to custom CSS file. Defaults to epub_style.css in the same folder as this script."
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Show full pandoc commands."
    )

    args = parser.parse_args()

    # ── Check pandoc ────────────────────────────────────────────────────────
    pandoc_ver = check_pandoc()
    if not pandoc_ver:
        print("ERROR: Pandoc is not installed or not in PATH.")
        print("Download from: https://pandoc.org/installing.html")
        sys.exit(1)
    print(f"Using {pandoc_ver}")

    # ── Resolve CSS ─────────────────────────────────────────────────────────
    script_dir = Path(__file__).parent
    css_path = Path(args.css) if args.css else script_dir / "epub_style.css"
    if not css_path.exists():
        print(f"ERROR: CSS file not found: {css_path}")
        sys.exit(1)
    print(f"Stylesheet: {css_path.name}")

    input_base = Path(args.input)
    output_base = Path(args.output)
    output_base.mkdir(parents=True, exist_ok=True)

    if not input_base.exists():
        print(f"ERROR: Input folder not found: {input_base}")
        sys.exit(1)

    # ── Determine mode: single folder or multi-language parent ──────────────
    has_docx = any(
        f for f in input_base.iterdir()
        if f.suffix.lower() == ".docx" and not f.name.startswith("~$")
    )
    has_subfolders = any(f for f in input_base.iterdir() if f.is_dir())

    all_results = {}

    if has_docx:
        # Single folder mode
        lang_code = args.lang or detect_language(input_base.name)
        print(f"\n📁 {input_base.name}  (language: {lang_code})")
        results = process_folder(input_base, output_base, css_path, lang_code, args.verbose)
        all_results[input_base.name] = results

    elif has_subfolders:
        # Multi-language parent folder mode
        subfolders = sorted([f for f in input_base.iterdir() if f.is_dir()])
        print(f"\nFound {len(subfolders)} language subfolder(s)\n")

        for folder in subfolders:
            lang_code = args.lang or detect_language(folder.name)
            out_dir = output_base / folder.name
            print(f"📁 {folder.name}  (language: {lang_code})")
            results = process_folder(folder, out_dir, css_path, lang_code, args.verbose)
            all_results[folder.name] = results
            print()
    else:
        print("ERROR: No .docx files or subfolders found in input directory.")
        sys.exit(1)

    # ── Summary ─────────────────────────────────────────────────────────────
    total = sum(len(v) for v in all_results.values())
    ok = sum(sum(1 for r in v if r["success"]) for v in all_results.values())
    failed = total - ok

    print("─" * 60)
    print(f"Done: {ok}/{total} files converted successfully")
    if failed:
        print(f"      {failed} file(s) failed — see report for details")

    # ── Write HTML report ───────────────────────────────────────────────────
    report_path = write_report(all_results, output_base)
    print(f"\nReport saved: {report_path}")
    print(f"EPUBs saved:  {output_base}")

    # Save JSON summary too (useful for scripting)
    json_path = output_base / "conversion_results.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
