# Cybermissions DOCX → EPUB Batch Converter

Converts folders of Word documents (.docx) to EPUB format for mobile devices.
Designed for 18-language theological education materials with tables and images.

---

## What You Need (One-Time Setup)

### 1. Install Python
- Download from: https://www.python.org/downloads/
- During install, **check the box: "Add Python to PATH"**
- Verify: open Command Prompt, type `python --version`

### 2. Install Pandoc
- Download from: https://pandoc.org/installing.html
- Use the Windows installer (.msi file)
- Verify: open Command Prompt, type `pandoc --version`

That's all you need. No other software required.

---

## How to Use

### Simple (Double-Click)
1. Double-click **`RUN_CONVERTER.bat`**
2. Type (or paste) the path to your language folders
3. Type (or paste) the path where EPUBs should be saved
4. Press Enter — conversion runs automatically

### Command Line (Advanced)
```
# Convert all language subfolders at once:
python convert.py --input "C:\Documents\Languages" --output "C:\EPUB_Output"

# Convert a single language folder:
python convert.py --input "C:\Documents\Languages\Swahili" --output "C:\EPUB_Output\Swahili"

# Specify language code manually (for accurate EPUB metadata):
python convert.py --input "C:\Languages\Hausa" --output "C:\Output\Hausa" --lang ha
```

---

## Folder Structure

**Input** — place your DOCX files like this:
```
Languages/
├── Swahili/
│   ├── Module1_Intro.docx
│   ├── Module2_Gospel.docx
│   └── Module3_Church.docx
├── French/
│   ├── Module1_Intro.docx
│   └── ...
└── Arabic/
    └── ...
```

**Output** — EPUBs are saved in matching structure:
```
EPUB_Output/
├── Swahili/
│   ├── Module1_Intro.epub
│   ├── Module2_Gospel.epub
│   └── Module3_Church.epub
├── French/
│   └── ...
├── conversion_report.html   ← Open this to review results
└── conversion_results.json  ← Machine-readable summary
```

---

## After Conversion — Review the Report

Open **`conversion_report.html`** in any web browser. It shows:
- ✓ Successfully converted files (with file size)
- ✗ Failed files (with error message)
- ⚠ Files that need manual attention (with specific reason)

---

## Auto-Detected Language Codes

The converter automatically detects language codes from folder names.
These languages are pre-configured:

| Folder Name    | Code | Folder Name    | Code |
|----------------|------|----------------|------|
| Afrikaans      | af   | Malagasy       | mg   |
| Amharic        | am   | Oromo          | om   |
| Arabic         | ar   | Portuguese     | pt   |
| Bengali        | bn   | Shona          | sn   |
| Burmese        | my   | Somali         | so   |
| Chinese        | zh   | Spanish        | es   |
| English        | en   | Swahili        | sw   |
| French         | fr   | Tagalog        | tl   |
| Hausa          | ha   | Tamil          | ta   |
| Hindi          | hi   | Tigrinya       | ti   |
| Indonesian     | id   | Urdu           | ur   |
| Igbo           | ig   | Yoruba         | yo   |
| Kiswahili      | sw   | Zulu           | zu   |

Arabic and Urdu are automatically set to right-to-left (RTL) layout.

If your folder name isn't in the list, use `--lang XX` to set the code manually.
Full list of codes: https://www.iana.org/assignments/language-subtag-registry

---

## Common Problems & Fixes

### "No navigation / no table of contents in the EPUB"
The DOCX file uses bold text for headings instead of Word's built-in heading styles.

**Fix in Word:**
1. Click on each chapter title
2. In the Home ribbon → Styles panel → click **Heading 1**
3. For sub-sections, use **Heading 2**, **Heading 3**
4. Save the file and reconvert

### "SmartArt diagram is missing"
SmartArt is a proprietary Word format that cannot be exported.

**Fix in Word:**
1. Right-click the SmartArt diagram
2. Select **Save as Picture** → choose PNG
3. Delete the SmartArt from the document
4. Insert the PNG image in its place
5. Save and reconvert

### "EMF or WMF image warning"
Windows vector image formats that don't display on mobile.

**Fix in Word:**
1. Right-click each affected image
2. Select **Save as Picture** → choose PNG
3. Delete the original image
4. Insert the PNG in its place

### "Table looks broken on phone"
Very wide tables with many columns are hard to read on small screens.

**Options:**
- Split the table into two narrower tables
- Rotate the table (use fewer columns, more rows)
- Convert to a simple list if the structure allows

### "Conversion failed entirely"
- Ensure both Python and Pandoc are installed (see Setup above)
- Make sure the file isn't open in Word (close it first)
- Check the file isn't corrupted (open it in Word to verify)

---

## Language Quality Tips

For the best EPUB output across 18 languages:

1. **Use Unicode throughout** — avoid legacy encoded fonts (common in some African language Word docs). The text should display correctly in Word without any special font installed.

2. **Embed fonts** — if your document uses a custom font for a specific language script, the EPUB will embed it automatically if the font is installed on the conversion computer.

3. **Check character encoding** — documents converted from older formats (e.g., old PDF scans) may have encoding issues that cause garbled text.

---

## About This Tool

Built for Cybermissions (cybermissions.org) to support free theological education
for church leaders across Africa and the emerging world.

Core technology: [Pandoc](https://pandoc.org) — the universal document converter.
