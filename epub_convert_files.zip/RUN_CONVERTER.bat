@echo off
:: ============================================================
::  Cybermissions DOCX → EPUB Converter
::  Double-click this file to run the converter.
::  Place this file in the same folder as convert.py
:: ============================================================

title Cybermissions EPUB Converter

echo.
echo  ========================================
echo   Cybermissions DOCX to EPUB Converter
echo  ========================================
echo.

:: Check Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python is not installed or not in PATH.
    echo  Download Python from: https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

:: Check Pandoc is available
pandoc --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Pandoc is not installed or not in PATH.
    echo  Download Pandoc from: https://pandoc.org/installing.html
    pause
    exit /b 1
)

echo  Both Python and Pandoc found. Good.
echo.

:: ── Ask for input folder ──────────────────────────────────────────────────
set /p INPUT_DIR="Enter the path to your language folders (or a single language folder): "
if not exist "%INPUT_DIR%" (
    echo.
    echo  ERROR: That folder does not exist: %INPUT_DIR%
    pause
    exit /b 1
)

:: ── Ask for output folder ─────────────────────────────────────────────────
set /p OUTPUT_DIR="Enter the path where EPUBs should be saved: "
if "%OUTPUT_DIR%"=="" (
    set OUTPUT_DIR=%~dp0output
)

echo.
echo  Input:  %INPUT_DIR%
echo  Output: %OUTPUT_DIR%
echo.
echo  Starting conversion...
echo  ----------------------------------------
echo.

:: Run the converter
python "%~dp0convert.py" --input "%INPUT_DIR%" --output "%OUTPUT_DIR%"

echo.
echo  ----------------------------------------
echo  Conversion complete.
echo  Your EPUB files are in: %OUTPUT_DIR%
echo  Open conversion_report.html to review results.
echo.

:: Offer to open the output folder
set /p OPEN_FOLDER="Open the output folder now? (Y/N): "
if /i "%OPEN_FOLDER%"=="Y" (
    explorer "%OUTPUT_DIR%"
)

pause
